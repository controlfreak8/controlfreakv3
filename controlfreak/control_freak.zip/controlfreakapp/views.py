from django.shortcuts import render
from .forms import FileUploadForm
from .models import TertiaryControlFile
from .utilities.process_files import create_control_point_objects
import time

def file_upload_view(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            files = request.FILES.getlist('files')
            for file in files:
                uploaded_file = TertiaryControlFile(file=file)
                file_hash = uploaded_file.save()
                time.sleep(1)
                if file_hash is not None:
                    uploaded_file = TertiaryControlFile.objects.get(file_hash=file_hash)


                print(uploaded_file.file.path)

                create_control_point_objects(uploaded_file)  # Replace with your processing function
            # Redirect or respond after processing
    else:
        form = FileUploadForm()
    return render(request, 'upload.html', {'form': form})

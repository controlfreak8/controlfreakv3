import os
import re
import zipfile
import logging
from typing import Optional
from typing import List, Dict, Any, Tuple

from .CONSTANTS import Helmert, OverPoint, ResectionPoint, ControlPoint, RESECTION_KEYS, OVER_POINT_KEYS

from .station_setup_parser import StationSetupParser
from .text_from_12d import TextFrom12dConverter, split_string, remove_parenthesis
from ..models import TertiaryControlFile, Coordinates, UnAdjustedTertiaryControlPoint, OverPointStationSetup


def create_control_point_objects(obj) -> list[dict[Any, Any] | dict[Any, ControlPoint]]:
    print(f'Processing {obj}...')
    path = obj.file.path
    raw_12da = TextFrom12dConverter(path).get_12da_text()

    lines = raw_12da.splitlines()
    tertiary_control_point = {}
    coordinates_collector = []
    point_data_collector = []
    final_collector = []
    has_setup_data = False
    target_type = 'Not specified'

    for i in range(len(lines)):

        if 'super ' in lines[i]:
            # if lines[i].startswith('super '):
            # Check if the next line starts with 'name'
            if i + 1 < len(lines) and 'name ' in lines[i + 1]:
                # try:
                target_type = remove_parenthesis(lines[i + 1].split()[1].strip())
                if target_type == '':
                    target_type = 'Not specified'

        # Collect the coordinates
        if 'data_3d' in lines[i]:
            has_setup_data = False
            # if lines[i].startswith('data_3d'):
            # will have as many lines as there are points
            coordinates_iterator = 1

            while True:
                line = lines[i + coordinates_iterator]

                try:
                    coordinates = [float(item) for item in line.split()]
                    coordinates_collector.append(coordinates + [target_type])
                    coordinates_iterator += 1

                except ValueError:
                    # Could not convert to float, so it must be the end of the coordinates
                    # if lines[i + coordinates_iterator + 1] == '}':
                    if '}' in lines[i + coordinates_iterator + 1]:
                        coordinates_collector.pop(-1)

                    point_data_iterator = coordinates_iterator + 2
                    break

            while True:
                # Got to the end of the set of coordinates or to the end of a file
                try:
                    if '}' in lines[i + point_data_iterator]:
                        # if lines[i + point_data_iterator] == '}':
                        break

                except IndexError:
                    break

                point_data = lines[i + point_data_iterator]  # get the next line
                point_data = split_string(point_data)  # split the line into a list of strings
                point_data_collector.extend(point_data)
                point_data_iterator += 1

        if "Inst Stat Setup" in lines[i]:
            # Get the setup data
            if not has_setup_data:

                setup_data = StationSetupParser(lines, i, obj).return_setup_object()

                has_setup_data = setup_data is not None

                if setup_data is not None:

                    merged = zip(point_data_collector, coordinates_collector)

                    collector = []

                    for point_data, coordinate in merged:
                        # As long as the coordinate is not already in the collector, add it and the point id
                        if coordinate not in collector:
                            # Create the control point using the class
                            collector.append([point_data] + coordinate)  # + [setup_hash_key])

                    for j, item in enumerate(collector):
                        pt_id = item[0]
                        #hash_key = create_hash(item[1:4])
                        if pt_id not in tertiary_control_point:
                            tertiary_control_point = {
                                pt_id:
                                    ControlPoint(
                                        id=item[0],
                                        easting=item[1],
                                        northing=item[2],
                                        elevation=item[3],
                                        target_type=item[4],
                                        horizontal_quality=4,
                                        vertical_quality=4,
                                        file_source=obj,
                                        adjusted=False,
                                    ),
                            }

                            final_collector.append(tertiary_control_point)
                    print(f'{len(final_collector)} control points for each setup')

                    for item in final_collector:

                        for key, tcp in item.items():
                            coordinates, created = Coordinates.objects.get_or_create(
                                easting=tcp.easting,
                                northing=tcp.northing,
                                elevation=tcp.elevation,
                                flavour='RW'
                            )

                            tertiary_cp_for_db, created = UnAdjustedTertiaryControlPoint.objects.get_or_create(
                                control_id=key,
                                coordinates=coordinates,
                                target_type=tcp.target_type,
                                horizontal_quality=4,
                                vertical_quality=4,
                                source=obj,
                                adjusted=False,
                            )

                            if created:
                                if setup_data.setup_type == 'Helmert':
                                    tertiary_cp_for_db.resection = setup_data
                                    tertiary_cp_for_db.save()
                                else:
                                    tertiary_cp_for_db.otp_setup = setup_data
                                    tertiary_cp_for_db.save()

                                print(f'Created {tertiary_cp_for_db}')
                            else:
                                print(setup_data.setup_type)
                                print(f'Already exists {tertiary_cp_for_db}')

    return final_collector